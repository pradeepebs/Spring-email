
 package com.example.restaurant_mail.demo_restaurant_mail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

import jakarta.mail.MessagingException;

@SpringBootApplication
public class DemoRestaurantMailApplication {
@Autowired
private EmailSenderService service;
	public static void main(String[] args) {
		SpringApplication.run(DemoRestaurantMailApplication.class, args);
	}
@EventListener(ApplicationReadyEvent.class)
/*
public void triggerMail() {
	service.sendSimpleEmail("upadhyaysimran163@gmail.com",
			"this is email in body side",
			"this is the subject email");
}*/

public void triggerMail() throws MessagingException {
	service.sendEmailWithAttachments("upadhyaysimran163@gmail.com",
			"Regarding java developer",
			"this is the subject email",
			"D:\\\\PRADEEP's JAVA_4.5YRS.pdf");
}
}
